﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Employees_Details.Models
{
    public class Employee
    {

        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Employee Name is required")]
        public string EmployeeName { get; set; }

        [Required(ErrorMessage = "Date of Birth is required")]
        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        [Required(ErrorMessage = "Please select Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Please select City")]
        public string City { get; set; }

        [Required(ErrorMessage = "Pin Code is required")]
        public string PinCode { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [RegularExpression(
            @"^[a-zA-Z0-9._%+-]+@gmail\.com$",
            ErrorMessage = "Only Gmail address is allowed"
        )]
        public string Email { get; set; }



        /* 
         CREATE TABLE [dbo].[Employee](
	[EmployeeId] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeName] [nvarchar](100) NOT NULL,
	[DateOfBirth] [date] NOT NULL,
	[Gender] [nvarchar](10) NOT NULL,
	[Address] [nvarchar](250) NOT NULL,
	[City] [nvarchar](50) NOT NULL,
	[PinCode] [nvarchar](10) NOT NULL,
	[Email] [nvarchar](150) NOT NULL) */
    }
}