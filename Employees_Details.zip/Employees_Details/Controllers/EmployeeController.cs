﻿using Employees_Details.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Employees_Details.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly string connectionString =
   ConfigurationManager.ConnectionStrings["MYDB"].ConnectionString;

        // GET: Employee
        public ActionResult Index(int? id)
        {
            Employee employee = new Employee();

            // Agar id mili hai to existing employee load hoga
            if (id.HasValue)
            {
                employee = GetEmployeeById(id.Value);

                if (employee == null)
                {
                    return HttpNotFound();
                }
            }

            // Grid ke liye saare employees
            ViewBag.Employees = GetAllEmployees();

            // City dropdown
            ViewBag.Cities = new SelectList(
                new[] { "Mumbai", "Pune", "Nashik", "Nagpur", "Thane" },
                employee.City
            );

            return View(employee);
        }


        // POST: Employee/Update
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Update(Employee employee)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"
                        UPDATE Employee
                        SET
                            EmployeeName = @EmployeeName,
                            DateOfBirth = @DateOfBirth,
                            Gender = @Gender,
                            Address = @Address,
                            City = @City,
                            PinCode = @PinCode,
                            Email = @Email
                        WHERE EmployeeId = @EmployeeId";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                        cmd.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
                        cmd.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                        cmd.Parameters.AddWithValue("@Gender", employee.Gender);
                        cmd.Parameters.AddWithValue("@Address", employee.Address);
                        cmd.Parameters.AddWithValue("@City", employee.City);
                        cmd.Parameters.AddWithValue("@PinCode", employee.PinCode);
                        cmd.Parameters.AddWithValue("@Email", employee.Email);

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }

                return RedirectToAction("Index");
            }

            ViewBag.Employees = GetAllEmployees();

            ViewBag.Cities = new SelectList(
                new[] { "Mumbai", "Pune", "Nashik", "Nagpur", "Thane" },
                employee.City
            );

            return View("Index", employee);
        }

        // POST: Employee/Add
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add(Employee employee)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string query = @"
                        INSERT INTO Employee
                        (
                            EmployeeName,
                            DateOfBirth,
                            Gender,
                            Address,
                            City,
                            PinCode,
                            Email
                        )
                        VALUES
                        (
                            @EmployeeName,
                            @DateOfBirth,
                            @Gender,
                            @Address,
                            @City,
                            @PinCode,
                            @Email
                        )";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
                        cmd.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                        cmd.Parameters.AddWithValue("@Gender", employee.Gender);
                        cmd.Parameters.AddWithValue("@Address", employee.Address);
                        cmd.Parameters.AddWithValue("@City", employee.City);
                        cmd.Parameters.AddWithValue("@PinCode", employee.PinCode);
                        cmd.Parameters.AddWithValue("@Email", employee.Email);

                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }

                return RedirectToAction("Index");
            }

            ViewBag.Employees = GetAllEmployees();

            ViewBag.Cities = new SelectList(
                new[] { "Mumbai", "Pune", "Nashik", "Nagpur", "Thane" },
                employee.City
            );

            return View("Index", employee);
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Employee WHERE EmployeeId = @EmployeeId";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@EmployeeId", id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return RedirectToAction("Index");
        }
        private List<Employee> GetAllEmployees()
        {
            List<Employee> employees = new List<Employee>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Employee";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            employees.Add(new Employee
                            {
                                EmployeeId = Convert.ToInt32(reader["EmployeeId"]),
                                EmployeeName = reader["EmployeeName"].ToString(),
                                DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]),
                                Gender = reader["Gender"].ToString(),
                                Address = reader["Address"].ToString(),
                                City = reader["City"].ToString(),
                                PinCode = reader["PinCode"].ToString(),
                                Email = reader["Email"].ToString()
                            });
                        }
                    }
                }
                return employees;
            }
        }


        // Get Employee By ID
        private Employee GetEmployeeById(int id)
        {
            Employee employee = null;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Employee WHERE EmployeeId = @EmployeeId";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@EmployeeId", id);

                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            employee = new Employee
                            {
                                EmployeeId = Convert.ToInt32(reader["EmployeeId"]),
                                EmployeeName = reader["EmployeeName"].ToString(),
                                DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]),
                                Gender = reader["Gender"].ToString(),
                                Address = reader["Address"].ToString(),
                                City = reader["City"].ToString(),
                                PinCode = reader["PinCode"].ToString(),
                                Email = reader["Email"].ToString()
                            };
                        }
                    }
                }
            }

            return employee;
        }

        
    }
}