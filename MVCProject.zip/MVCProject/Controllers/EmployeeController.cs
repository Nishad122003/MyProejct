﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCProject.Models;

namespace MVCProject.Controllers
{
    public class EmployeeController : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();


        // GET: Employee
        //public ActionResult Index()
        //{
        //    return View();
        //}

        // =========================
        // PAGE LOAD
        // =========================

        public ActionResult Index(int? id)
        {
            Employee employee;

            if (id == null)
            {
                // New employee
                employee = new Employee();
            }
            else
            {
                // Existing employee
                employee = db.Employees.Find(id);

                if (employee == null)
                {
                    return HttpNotFound();
                }
            }


            // Grid data
            ViewBag.Employees = db.Employees
                                  .OrderByDescending(x => x.EmployeeId)
                                  .ToList();

            // City dropdown
            ViewBag.Cities = new SelectList(
                new[]
                {
                    "Delhi",
                    "Mumbai",
                    "Pune",
                    "Bengaluru",
                    "Hyderabad",
                    "Chennai",
                    "Kolkata"
                },
                employee.City
            );


            return View(employee);
        }


        // =========================
        // ADD
        // =========================

        [HttpPost]
        public ActionResult Add(Employee employee)
        {
            if (ModelState.IsValid)
            {
                db.Employees.Add(employee);

                db.SaveChanges();

                return RedirectToAction("Index");
            }

            // Validation fail होने पर same form वापस
            ViewBag.Employees = db.Employees
                                  .OrderByDescending(x => x.EmployeeId)
                                  .ToList();

            ViewBag.Cities = new SelectList(
                new[]
                {
            "Delhi",
            "Mumbai",
            "Pune",
            "Bengaluru",
            "Hyderabad",
            "Chennai",
            "Kolkata"
                },
                employee.City
            );

            return View("Index", employee);

        }

        // =========================
        // UPDATE
        // =========================

        [HttpPost]
        public ActionResult Update(Employee employee)
        {
            if (ModelState.IsValid)
            {
                Employee existingEmployee =
                    db.Employees.Find(employee.EmployeeId);

                if (existingEmployee != null)
                {
                    existingEmployee.EmployeeName =
                        employee.EmployeeName;

                    existingEmployee.DateOfBirth =
                        employee.DateOfBirth;

                    existingEmployee.Gender =
                        employee.Gender;

                    existingEmployee.Address =
                        employee.Address;

                    existingEmployee.City =
                        employee.City;

                    existingEmployee.PinCode =
                        employee.PinCode;

                    existingEmployee.EmailId =
                        employee.EmailId;


                    db.SaveChanges();
                }
            }

            return RedirectToAction("Index");
        }

        // =========================
        // DELETE
        // =========================

        [HttpPost]
        public ActionResult Delete(int id)
        {
            Employee employee = db.Employees.Find(id);

            if (employee != null)
            {
                db.Employees.Remove(employee);

                db.SaveChanges();
            }

            return RedirectToAction("Index");
        }

        // =========================
        // DISPOSE
        // =========================

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }

            base.Dispose(disposing);
        }
        // PAGE LOAD
        //public ActionResult Index(int? id)
        //{
        //    Employee employee;

        //    if (id == null)
        //    {
        //        // New Insert
        //        employee = new Employee();
        //    }
        //    else
        //    {
        //        // Update ke liye data load
        //        employee = db.Employees.Find(id);

        //        if (employee == null)
        //        {
        //            return HttpNotFound();
        //        }
        //    }

        //    ViewBag.Employees = db.Employees
        //                          .OrderByDescending(x => x.Id)
        //                          .ToList();

        //    return View(employee);
        //}

        //// INSERT
        //[HttpPost]
        //public ActionResult Insert(Employee employee)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Employees.Add(employee);

        //        db.SaveChanges();
        //    }

        //    return RedirectToAction("Index");
        //}


        //// UPDATE
        //[HttpPost]
        //public ActionResult Update(Employee employee)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        Employee oldEmployee = db.Employees.Find(employee.Id);

        //        if (oldEmployee != null)
        //        {
        //            oldEmployee.Name = employee.Name;
        //            oldEmployee.Age = employee.Age;
        //            oldEmployee.City = employee.City;

        //            db.SaveChanges();
        //        }
        //    }

        //    return RedirectToAction("Index");
        //}

        //// DELETE
        //public ActionResult Delete(int id)
        //{
        //    Employee employee = db.Employees.Find(id);

        //    if (employee != null)
        //    {
        //        db.Employees.Remove(employee);

        //        db.SaveChanges();
        //    }

        //    return RedirectToAction("Index");
        //}
    }
}