﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace MVCProject.Models
{
    //[Table("Employee")]
    public class Employee
    {
        //public int Id { get; set; }

        //public string Name { get; set; }

        //public int Age { get; set; }

        //public string City { get; set; }
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmployeeId { get; set; }

        [Required(ErrorMessage = "Employee Name is required")]
        public string EmployeeName { get; set; }

        [Required(ErrorMessage = "Date of Birth is required")]
        public DateTime? DateOfBirth { get; set; }

        [Required(ErrorMessage = "Please select Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Please select City")]
        public string City { get; set; }

        [Required(ErrorMessage = "Pin Code is required")]
        [RegularExpression(@"^\d{6}$",
            ErrorMessage = "Pin Code must be 6 digits")]
        public string PinCode { get; set; }

        [Required(ErrorMessage = "Email ID is required")]
        [EmailAddress(ErrorMessage = "Enter a valid Email ID")]
       // [RegularExpression( @"^[a-zA-Z0-9._%+-]+@gmail\.com$", ErrorMessage = "Only Gmail ID is allowed")]
        public string EmailId { get; set; }
    }
}