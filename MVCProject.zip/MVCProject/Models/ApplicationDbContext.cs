﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MVCProject.Models
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext()
            : base("MyDbConnection")
        {
        }

        public DbSet<Employee> Employees { get; set; }

        static ApplicationDbContext()
        {
            Database.SetInitializer<ApplicationDbContext>(null);
        }
    }
}